package com.pool.util;

public enum GameObjectTag {
	TABLE,
	BALL
}
