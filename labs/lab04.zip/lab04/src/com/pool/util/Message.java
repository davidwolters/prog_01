package com.pool.util;

public enum Message {
}
