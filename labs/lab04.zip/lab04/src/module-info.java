/**
 * 
 */
/**
 * @author david
 *
 */
module lab04 {
	requires java.desktop;
}