package com.clock.util;

public enum TimeHandType {
	HOUR,
	MINUTE,
	SECOND
}
