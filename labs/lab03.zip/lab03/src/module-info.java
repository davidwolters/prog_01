/**
 * 
 */
/**
 * @author david
 *
 */
module lab03 {
	requires java.desktop;
}